export default async function handler(ctx) {
  const probe = await ctx.config.get('PROBE');
  const value = await ctx.fetch('https://origin.example/value').text();
  return ctx.text(probe + ':' + value);
}
