Qualify a nonterminal service against the shared lifecycle points before RA-06. A checked private effect slot suspends through the original Native driver, delivers a probe result and continues into ordinary core fetch. Production contracts, admission and provider sources are unchanged.

The proof covers authentication, rejection, cancellation, late observation, conservative unknown claims, post-closure cleanup, deadline consumption and traps. It also distinguishes accepted failure-placeholder delivery from business success so the original service error stays primary. This clears the bounded lifecycle checkpoint for a cache mapping; real-host disposition, package-completion variants and joint cache/fetch accounting remain separate.

Validation: 38 compiled-Native cases, five detected mutations, disabled source/Wasm identity and registration-order identity. Existing terminal/forwarding controls and required documentation/maintenance checks are recorded in the evidence bundle.

<!-- pulse-maintainer-declaration:start -->
Change class: evidence
Scope: evidence-only
Protected boundaries: none
Human decision: not-required
<!-- pulse-maintainer-declaration:end -->
