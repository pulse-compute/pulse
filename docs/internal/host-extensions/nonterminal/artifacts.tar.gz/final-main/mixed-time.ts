import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const value = await ctx.parallel({ sample: metrics.snapshot(ctx), time: ctx.time.now() }); return ctx.json(value);
}
