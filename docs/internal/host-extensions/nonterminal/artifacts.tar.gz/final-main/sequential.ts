import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const first = await metrics.snapshot(ctx); const second = await metrics.snapshot(ctx); return ctx.json({ first, second });
}
