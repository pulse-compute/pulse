import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
return ctx.text('ok');
}
