import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const value = await metrics.snapshot(ctx); return ctx.json(value);
}
