import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const value = await downstream.tls(ctx); return ctx.json(value);
}
