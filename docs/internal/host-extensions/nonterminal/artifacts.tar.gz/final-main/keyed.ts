import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const value = await ctx.parallel({ metrics: metrics.snapshot(ctx), tls: downstream.tls(ctx) }); return ctx.json(value);
}
