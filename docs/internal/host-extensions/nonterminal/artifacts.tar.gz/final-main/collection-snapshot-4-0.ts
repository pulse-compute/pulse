import { metrics, downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
const inputs = [];
const effects = ctx.effects({ max: 4 });
for (const item of inputs) { effects.add(metrics.snapshot(ctx)); }
const values = await ctx.parallel(effects);
return ctx.json(values);
}
