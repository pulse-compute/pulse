import { downstream } from '@hex-spike/observations';
export default async function handler(ctx) {
  const tls = await downstream.tls(ctx);
  if (tls.protocol.status === 'available') {
    return ctx.text(tls.protocol.value);
  }
  return ctx.text('not-present');
}
