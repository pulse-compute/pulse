import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const inputs=[];const effects=ctx.effects({max:4});for(const item of inputs){effects.add(cache.getOrSetText(ctx,'alpha','https://origin.example/value'));}const value=await ctx.parallel(effects);return ctx.json(value);
}
