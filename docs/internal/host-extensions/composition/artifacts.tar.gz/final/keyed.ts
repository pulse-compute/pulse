import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const value=await ctx.parallel({first:cache.getOrSetText(ctx,'alpha','https://origin.example/value'),second:cache.getOrSetText(ctx,'beta','https://origin.example/other')});return ctx.json(value);
}
