import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const inputs=[0,1,2,3,4,5,6,7];const effects=ctx.effects({max:8});for(const item of inputs){effects.add(cache.getOrSetText(ctx,'alpha','https://origin.example/value'));}const value=await ctx.parallel(effects);return ctx.json(value);
}
