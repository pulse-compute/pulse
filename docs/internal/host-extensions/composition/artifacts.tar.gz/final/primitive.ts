import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const value=await cache.getText(ctx,'alpha');return ctx.json(value);
}
