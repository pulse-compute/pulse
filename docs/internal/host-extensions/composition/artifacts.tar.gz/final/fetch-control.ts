export default async function handler(ctx){
const value=await ctx.fetch('https://origin.example/value').text();return ctx.text(value);
}
