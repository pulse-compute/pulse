import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const value=await ctx.parallel({item:cache.getOrSetText(ctx,'alpha','https://origin.example/value'),clock:ctx.time.now()});return ctx.json(value);
}
