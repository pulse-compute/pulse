import { cache } from '@hex-spike/cache';
export default async function handler(ctx){
const value=await cache.getOrSetText(ctx,'alpha','https://origin.example/value');return ctx.json(value);
}
