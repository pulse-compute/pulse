'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
const p=require('./prototype.cjs'),{create}=require('./fixture.cjs'),{execute}=require('./host.cjs');
const compiler=require(path.join(p.root,'wasm/packages/compiler/src/canonical-project-compiler'));
const {buildCanonicalNativePlan}=require(path.join(p.root,'wasm/packages/compiler/src/canonical-native-plan'));
const platform=require(path.join(p.root,'packages/provider-fastly/src/build/native-platform-capabilities'));
const output=path.resolve(process.argv[2]||'/tmp/hex-bounded-composition');fs.mkdirSync(output,{recursive:true});
const directory=fs.mkdtempSync(path.join(p.root,'wasm/.test-results/hex-composition-')),fixture=create(directory);
const git=(...a)=>execFileSync('git',a,{cwd:p.root,encoding:'utf8'}).trim();
const receipt={version:'hex.bounded-composition.v0',status:'running',revision:git('rev-parse','HEAD'),workingTree:git('status','--porcelain'),node:process.version,inputs:['prototype.cjs','service.as.ts','fixture.cjs','host.cjs','run.cjs','../ownership/prototype.cjs','../ownership/service.as.ts'].map(file=>({file,sha256:p.hash(fs.readFileSync(path.join(__dirname,file)))})),artifacts:[],cases:[]};
const hooks=`
export function ro_peak():i32{return __ro_peak}
export function ro_owned_count():i32{return __ro_handles}
export function ro_unresolved():i32{return __ro_unresolved}
export function ro_cleanup_errors():i32{return __ro_cleanup_errors}
export function ro_commits():i32{return __ro_commit_attempts}
export function ro_close():void{__pulse_invocation_close()}
export function ro_count(n:i32):void{__pulse_invocation_count=n}
export function ro_ticket(i:i32):i32{return unchecked(__pulse_invocation_tickets[i])}
export function ro_settle(i:i32,t:i32,v:i32):i32{return __pulse_invocation_settle(i,t,v)}
`;
const compositionHooks=`
export function bc_passes():i32{return __bc_passes}
export function bc_invocations():i32{return __pulse_invocation_count}
export function bc_progress():i32{return __bc_progress}
`;
const source=(body,imports=true)=>(imports?`import { cache } from '${p.PACKAGE}';\n`:'')+`export default async function handler(ctx){\n${body}\n}\n`;
function canonical(authored){fixture.write(authored);return compiler.compileCanonicalProject(fixture.file,{rootDir:directory,workspaceRoot:directory,target:'native',packageTargetDescriptor:p.TARGET});}
let fetchTemplate;
function compile(name,authored,{prototype=true,instrument=true}={}){
  const c=canonical(authored),canonicalPlan=buildCanonicalNativePlan(c),plan=p.expand(canonicalPlan,fetchTemplate);
  const options={cwd:p.root,canonicalBuild:true,requirePlatformCapability:false,bindings:{backends:{'https://origin.example':'origin'}},maxDurationMs:1000,realizationArtifacts:p.artifacts()};
  const native=prototype?p.withPrototype(()=>platform.compileFastlyNativePlatformCapabilitiesPlan(plan,options),instrument?hooks+(plan.composition.roots.length?compositionHooks:''):''):platform.compileFastlyNativePlatformCapabilitiesPlan(canonicalPlan,options);
  const row={name,bytes:native.wasm.length,sha256:p.hash(native.wasm),sourceSha256:p.hash(authored),generatedSha256:p.hash(native.source),canonicalSlots:canonicalPlan.effects.length,expandedSlots:plan.effects.length,roots:plan.composition.roots,imports:native.inspection.imports,instrumented:instrument};receipt.artifacts.push(row);
  for(const [suffix,data] of [['wasm',native.wasm],['as.ts',native.source],['ts',authored],['manifest.json',JSON.stringify(native.manifest,null,2)],['canonical-plan.json',JSON.stringify(canonicalPlan,null,2)],['plan.json',JSON.stringify(plan,null,2)]])fs.writeFileSync(path.join(output,name+'.'+suffix),data);
  return {native,row,plan};
}
function check(name,fn){try{const detail=fn();receipt.cases.push({name,status:'passed',detail});console.log('ok - '+name);}catch(e){receipt.cases.push({name,status:'failed',error:e.stack});throw e;}}
function run(built,options={}){const r=execute(built.native.wasm,options);delete r.instance;return r;}
function success(built,options={}){const r=run(built,options);assert.equal(r.thrown,null);assert.equal(r.error,0);assert.equal(r.status,200);assert.equal(r.counters?.owned??0,0);return r;}
try{
  const fc=canonical(source("const value=await ctx.fetch('https://origin.example/value').text(); return ctx.text(value);",false));
  fetchTemplate=buildCanonicalNativePlan(fc).effects[0];fs.writeFileSync(path.join(output,'fetch-template.json'),JSON.stringify(fetchTemplate,null,2));
  const call="cache.getOrSetText(ctx,'alpha','https://origin.example/value')";
  const direct=compile('direct',source(`const value=await ${call};return ctx.json(value);`));
  check('Direct hit skips loader and insert',()=>{const r=success(direct);assert.deepEqual(r.json,{status:'hit',value:'value:alpha'});assert.equal(r.composition.invocations,2);return r;});
  check('Direct miss runs fetch and insert',()=>{const r=success(direct,{miss:true});assert.deepEqual(r.json,{status:'stored',value:'loaded'});assert.equal(r.composition.invocations,4);assert.equal(r.committed.length,1);return r;});
  receipt.status='passed';
}catch(e){receipt.status='failed';receipt.error=e.stack;process.exitCode=1;console.error(e.stack);}
finally{fs.rmSync(directory,{recursive:true,force:true});fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({status:receipt.status,cases:receipt.cases.length,output}));}
