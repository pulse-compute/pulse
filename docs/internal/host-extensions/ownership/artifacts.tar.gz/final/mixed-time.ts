import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const value=await ctx.parallel({time:ctx.time.now(),cache:cache.getText(ctx,'alpha')}); return ctx.json(value);
}
