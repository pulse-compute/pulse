import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const inputs=[]; const effects=ctx.effects({max:4}); for(const item of inputs){effects.add(cache.getText(ctx,'alpha'));} const values=await ctx.parallel(effects); return ctx.json(values);
}
