import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const inputs=[0,1]; const effects=ctx.effects({max:4}); for(const item of inputs){effects.add(cache.putText(ctx,'alpha','payload'));} const values=await ctx.parallel(effects); return ctx.json(values);
}
