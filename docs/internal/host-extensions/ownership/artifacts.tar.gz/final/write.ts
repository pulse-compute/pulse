import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const value=await cache.putText(ctx,'alpha','payload'); return ctx.json(value);
}
