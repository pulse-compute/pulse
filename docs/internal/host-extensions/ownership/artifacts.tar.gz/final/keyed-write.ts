import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const value=await ctx.parallel({a:cache.putText(ctx,'alpha','first'),b:cache.putText(ctx,'beta','second')}); return ctx.json(value);
}
