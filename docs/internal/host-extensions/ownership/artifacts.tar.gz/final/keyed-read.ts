import { cache } from '@hex-spike/cache';
export default async function handler(ctx) {
const value=await ctx.parallel({a:cache.getText(ctx,'alpha'),b:cache.getText(ctx,'beta')}); return ctx.json(value);
}
