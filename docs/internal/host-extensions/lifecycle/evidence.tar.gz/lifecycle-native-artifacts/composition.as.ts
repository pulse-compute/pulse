
@external("probe", "send") declare function __pulse_response_send_raw(handle:i32, body:i32, streaming:i32):i32
@external("probe", "deliver") declare function deliver():i32
const PULSE_ERROR_STATE:i32=2
let failure:i32=0
function __pulse_fastly_fail(code:i32,stage:i32,index:i32):void { failure=stage }
let __pulse_fastly_request_body_handle:i32=-1
let __pulse_extension_handles_owned:bool=false
let __pulse_extension_slot:i32=0
let __pulse_extension_invocation:i32=7
let __pulse_extension_token:i32=99
let __pulse_extension_delivering:bool=false
let __pulse_extension_settled:bool=false
let __pulse_invocation_closed:bool=false
let cleanup:i32=0
let __fwd_source:i32=-1
let __fwd_result:i32=88
let fwdError:bool=false
let events:i32=0
function __pulse_extension_slot_of(i:i32):i32 { return i==0?0:-1 }
function __pulse_extension_cleanup():void { if(__pulse_extension_handles_owned && __pulse_response_authority!=1){cleanup++;__pulse_extension_handles_owned=false;} }
function __fwd_cleanup():void { if(__fwd_source>=0){cleanup++;__fwd_source=-1;} }
function __fwd_error_response():bool { if(!fwdError)return false;__pulse_fastly_send_result(55);return true }
function __fwd_send():i32 { return fastly_http_resp_send_downstream(1,2,1) }
function __pulse_fastly_jwt_attach_evidence(result:i32):void {}
function __pulse_fastly_run_invocation():void {}
function __pulse_invocation_close(): void {
  __pulse_hook_invocation_close()
  __pulse_invocation_closed=true
}
function __pulse_invocation_settle(index: i32, ticket: i32, result: i32): i32 {
  if (!__pulse_hook_effect_settle(index, ticket, result)) return 0
  __pulse_hook_effect_deliver_before(index, result)
  const accepted = pulse_set_effect_result(index, result)
  __pulse_hook_effect_deliver_after(index, result, accepted)
  return accepted
}
export function pulse_set_effect_result(effectIndex: i32, handle: i32): i32 {
  if (!__pulse_hook_effect_result(effectIndex, handle)) return 0
  return deliver()
}
function __pulse_fastly_jwt_send_error(): void {
  if (!__pulse_hook_response_authority()) return;
  if (__pulse_hook_response_error()) return;
  __pulse_fastly_send_result(11)
}
function __request_send_timeout(): void {
  if (!__pulse_hook_response_authority()) return;
  __pulse_fastly_send_result(12)
}
function __pulse_fastly_send_result(handle: i32): i32 {
  if (!__pulse_hook_response_authority()) { __pulse_fastly_fail(PULSE_ERROR_STATE, 282, -1); return PULSE_ERROR_STATE; }
  return fastly_http_resp_send_downstream(handle,2,0)
}
export function acquired():void {
  const handles=new StaticArray<i32>(2);unchecked(handles[1]=42)
  __pulse_fastly_request_body_handle = load<i32>(changetype<usize>(handles) + 4)
  __pulse_hook_request_acquired()
}
export function end():void {
  __pulse_fastly_run_invocation()
  __pulse_hook_invocation_end()
  __pulse_invocation_close()
}
export function final(result:i32):void {
  if (__pulse_hook_result_claim(result)) return
  __pulse_fastly_jwt_attach_evidence(result)
  __pulse_fastly_send_result(result)
}
export function send():i32 { return __pulse_fastly_send_result(10) }
export function timeout():void { __request_send_timeout() }
export function error():void { __pulse_fastly_jwt_send_error() }
export function forwardError():void { fwdError=true;__pulse_fastly_jwt_send_error() }
export function begin():bool { return __pulse_response_begin() }
export function transfer():void { __pulse_response_transferred() }
export function settle(i:i32,t:i32,r:i32):i32 { return __pulse_invocation_settle(i,t,r) }
export function query(k:i32):i32 {
  if(k==0)return __pulse_response_authority
  if(k==1)return cleanup
  if(k==2)return events
  if(k==3)return __pulse_extension_delivering?1:0
  if(k==4)return __pulse_extension_settled?1:0
  return failure
}

// 0 owned; 1 dispatch outcome unknown; 2 transferred; 3 locally completed.
// Completion is not a delivery receipt. Nonzero status or trap never reopens it.
let __pulse_response_authority: i32 = 0
function __pulse_response_owned(): bool { return __pulse_response_authority == 0 }
function __pulse_response_begin(): bool {
  if (!__pulse_response_owned()) { __pulse_fastly_fail(PULSE_ERROR_STATE, 282, -1); return false }
  __pulse_response_authority = 1
  return true
}
function __pulse_response_transferred(): void {
  if (__pulse_response_authority == 1) __pulse_response_authority = 2
}
function __pulse_response_complete(): void {
  if (__pulse_response_authority == 2) __pulse_response_authority = 3
}
function fastly_http_resp_send_downstream(handle: i32, body: i32, streaming: i32): i32 {
  if (!__pulse_response_begin()) return PULSE_ERROR_STATE
  const status = __pulse_response_send_raw(handle, body, streaming)
  if (status == 0) {
    __pulse_response_transferred()
    if (streaming == 0) __pulse_response_complete()
  }
  return status
}

// Lifecycle hooks (driver-owned points, provider-service contributions)
function __pulse_hook_request_acquired_0(): void {
  __pulse_extension_handles_owned = true
}
function __pulse_hook_request_acquired_1(): void {
  __fwd_source = __pulse_fastly_request_body_handle
}
function __pulse_hook_request_acquired(): void { __pulse_hook_request_acquired_0(); __pulse_hook_request_acquired_1(); }
function __pulse_hook_effect_settle_0(index: i32, ticket: i32, result: i32): bool {
  if (!(__pulse_extension_slot_of(index) >= 0)) return true
  if (!(__pulse_extension_slot_of(index) == __pulse_extension_slot) || __pulse_response_authority != 2 || __pulse_extension_settled || ticket != __pulse_extension_invocation || result != __pulse_extension_token || result <= 0) {
    __pulse_fastly_fail(PULSE_ERROR_STATE, 284, index); return false
  }
  return true
}
function __pulse_hook_effect_settle(index: i32, ticket: i32, result: i32): bool { if (!__pulse_hook_effect_settle_0(index, ticket, result)) return false; return true }
function __pulse_hook_effect_deliver_0_before(index: i32, result: i32): void {
events=events*10+1
}
function __pulse_hook_effect_deliver_0_after(index: i32, result: i32, accepted: i32): void {
events=events*10+4
}
function __pulse_hook_effect_deliver_1_before(index: i32, result: i32): void {
  __pulse_extension_delivering = __pulse_extension_slot_of(index) >= 0
}
function __pulse_hook_effect_deliver_1_after(index: i32, result: i32, accepted: i32): void {
  __pulse_extension_delivering = false
  if (__pulse_extension_slot_of(index) >= 0 && accepted == 1) __pulse_extension_settled = true
}
function __pulse_hook_effect_deliver_2_before(index: i32, result: i32): void {
events=events*10+2
}
function __pulse_hook_effect_deliver_2_after(index: i32, result: i32, accepted: i32): void {
events=events*10+3
}
function __pulse_hook_effect_deliver_before(index: i32, result: i32): void { __pulse_hook_effect_deliver_0_before(index, result); __pulse_hook_effect_deliver_1_before(index, result); __pulse_hook_effect_deliver_2_before(index, result); }
function __pulse_hook_effect_deliver_after(index: i32, result: i32, accepted: i32): void { __pulse_hook_effect_deliver_2_after(index, result, accepted); __pulse_hook_effect_deliver_1_after(index, result, accepted); __pulse_hook_effect_deliver_0_after(index, result, accepted); }
function __pulse_hook_effect_result_0(effectIndex: i32, handle: i32): bool {
  if (!(__pulse_extension_slot_of(effectIndex) >= 0)) return true
  if (!(__pulse_extension_slot_of(effectIndex) == __pulse_extension_slot) || !__pulse_extension_delivering || __pulse_response_authority != 2 || __pulse_extension_settled || handle != __pulse_extension_token || __pulse_invocation_closed) {
    __pulse_fastly_fail(PULSE_ERROR_STATE, 284, effectIndex); return false
  }
  return true
}
function __pulse_hook_effect_result(effectIndex: i32, handle: i32): bool { if (!__pulse_hook_effect_result_0(effectIndex, handle)) return false; return true }
function __pulse_hook_invocation_close_0(): void {
  __pulse_extension_cleanup()
  __pulse_extension_token = 0
  __pulse_extension_invocation = 0
  __pulse_extension_delivering = false
}
function __pulse_hook_invocation_close(): void { __pulse_hook_invocation_close_0(); }
function __pulse_hook_invocation_end_0(): void {
  __fwd_cleanup()
}
function __pulse_hook_invocation_end(): void { __pulse_hook_invocation_end_0(); }
function __pulse_hook_response_error_0(): bool {
  return __fwd_error_response()
}
function __pulse_hook_response_error(): bool { if (__pulse_hook_response_error_0()) return true; return false }
function __pulse_hook_response_authority_0(): bool {
  return __pulse_response_owned()
}
function __pulse_hook_response_authority(): bool { if (!__pulse_hook_response_authority_0()) return false; return true }
function __pulse_hook_result_claim_0(result: i32): bool {
  if (__pulse_response_authority == 0) return false
  if (__pulse_response_authority != 2 || !__pulse_extension_settled || result != __pulse_extension_token || __pulse_extension_token <= 0) { __pulse_fastly_fail(PULSE_ERROR_STATE, 283, -1); return true }
  __pulse_response_complete()
  __pulse_extension_token = 0
  return true
}
function __pulse_hook_result_claim_1(result: i32): bool {
  if (result != __fwd_result || result == 0) return false
  if (__pulse_response_owned()) __fwd_send()
  return true
}
function __pulse_hook_result_claim(result: i32): bool { if (__pulse_hook_result_claim_0(result)) return true; if (__pulse_hook_result_claim_1(result)) return true; return false }
