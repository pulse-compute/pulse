RA-08 internal evidence. attempt-1 through attempt-5 retain every formal run, exact inputs and all emitted artifacts. See receipts for terminal status. control-ra07 is an unchanged replay with exact inputs. Exploratory runs have generated artifacts but no complete input snapshot and are not qualification evidence. Raw fixture traces deliberately contain synthetic handles and test values; versioned report sidecars are separately redacted. SHA256SUMS.json authenticates every member except itself. Identical bytes are stored as tar hard links. No real Fastly host executed.

1: Count-only mode attempted a zero-byte static allocation; compiler rejected it.
2: Exact executable comparison correctly rejected separately compiled controls with differing optimized layout. Matched variants now share one control artifact.
3: Core sibling decoding during continuation resumption exposed stale driver-slot attribution. Attribution now occurs at adapter allocation sites.
4: Passed 68 cases and 5 mutations; final review then tightened profile isolation and record lifetime validation.
5: Final: passed 70 cases and 5 mutations.
