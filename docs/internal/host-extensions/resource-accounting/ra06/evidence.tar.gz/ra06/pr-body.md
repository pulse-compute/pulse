Integrate the experimental cache owner with resource accounting and shared lifecycle hooks in a bounded Native proof. Fixed read/write cohorts reserve capacity before acquisition; cache lookup/read/close and insert/write/commit/abandon preserve distinct ownership outcomes and the original driver deadline.

The adapter stops undispatched siblings after a known acquisition failure, retains uncertain handle and backing-byte claims, and cleans only qualified resources after ticket invalidation. It never commits an incomplete writer as cleanup or closes an unready lookup. A timeout or later sibling failure can follow an already committed write; no atomicity or rollback is promised.

Validation: 94 compiled-Native cases at widths 1/2/8/16/32, seven detected mutations, import-policy/signature audits, absent source/Wasm identity and zero imported-unused size growth. The prior nonterminal proof replays 38 cases and five mutations. Exact inputs, artifacts, full traces, earlier attempts and required local documentation/maintenance checks are indexed in the evidence bundle.

This is evidence-only: production service admission is explicitly rejected, and production source is unchanged. Joint cache/fetch admission and accounting remain RA-07; real-host disposition, JavaScript parity and matched runtime cost remain separate.

<!-- pulse-maintainer-declaration:start -->
Change class: evidence
Scope: evidence-only
Protected boundaries: none
Human decision: not-required
<!-- pulse-maintainer-declaration:end -->
