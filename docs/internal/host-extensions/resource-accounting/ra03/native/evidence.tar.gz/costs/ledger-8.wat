(module
 (type $0 (func (param i32) (result i32)))
 (type $1 (func (param i32 i32) (result i32)))
 (type $2 (func (result i32)))
 (type $3 (func (param i32 i32 i32) (result i32)))
 (type $4 (func (param i32 i32 i32 i32 i32) (result i32)))
 (type $5 (func))
 (type $6 (func (param i32)))
 (type $7 (func (param i32 i32 i32 i32) (result i32)))
 (global $global$0 (mut i32) (i32.const 0))
 (global $global$1 (mut i32) (i32.const 0))
 (global $global$2 (mut i32) (i32.const 0))
 (global $global$3 (mut i32) (i32.const 0))
 (global $global$4 (mut i32) (i32.const 0))
 (global $global$5 (mut i32) (i32.const 0))
 (global $global$6 (mut i32) (i32.const 0))
 (global $global$7 (mut i32) (i32.const 0))
 (global $global$8 (mut i32) (i32.const 0))
 (global $global$9 (mut i32) (i32.const 0))
 (global $global$10 (mut i32) (i32.const 0))
 (global $global$11 (mut i32) (i32.const 0))
 (global $global$12 (mut i32) (i32.const 0))
 (global $global$13 (mut i32) (i32.const 0))
 (global $global$14 (mut i32) (i32.const 0))
 (global $global$15 (mut i32) (i32.const 0))
 (global $global$16 (mut i32) (i32.const 0))
 (memory $0 1)
 (export "na_init" (func $15))
 (export "na_now" (func $26))
 (export "na_capture" (func $19))
 (export "na_member" (func $14))
 (export "na_admit" (func $20))
 (export "na_deny" (func $29))
 (export "na_child" (func $18))
 (export "na_settle_child" (func $12))
 (export "na_step" (func $11))
 (export "na_prepare" (func $7))
 (export "na_adopt" (func $9))
 (export "na_observe" (func $8))
 (export "na_handoff" (func $27))
 (export "na_refund" (func $13))
 (export "na_finish" (func $16))
 (export "na_stop" (func $23))
 (export "na_end" (func $17))
 (export "na_exit" (func $28))
 (export "na_unexpected" (func $22))
 (export "na_query" (func $24))
 (export "na_bytes" (func $30))
 (export "na_ptr" (func $25))
 (export "na_bench" (func $31))
 (export "memory" (memory $0))
 (func $0 (param $0 i32) (result i32)
  (global.set $global$9
   (local.get $0)
  )
  (i32.sub
   (i32.const 0)
   (local.get $0)
  )
 )
 (func $1 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (if
   (i32.le_s
    (local.get $0)
    (i32.const 0)
   )
   (then
    (return
     (call $0
      (i32.const 4)
     )
    )
   )
  )
  (local.set $1
   (i32.div_s
    (local.tee $0
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
    )
    (i32.const 16)
   )
  )
  (if
   (if (result i32)
    (i32.load
     (i32.add
      (local.tee $2
       (i32.mul
        (local.tee $0
         (i32.rem_s
          (local.get $0)
          (i32.const 16)
         )
        )
        (i32.const 60)
       )
      )
      (i32.const 1028)
     )
    )
    (then
     (i32.ne
      (local.get $1)
      (i32.load
       (i32.add
        (local.get $2)
        (i32.const 1024)
       )
      )
     )
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (return
     (call $0
      (i32.const 4)
     )
    )
   )
  )
  (local.get $0)
 )
 (func $2 (param $0 i32) (result i32)
  (if
   (global.get $global$8)
   (then
    (return
     (call $0
      (i32.const 1)
     )
    )
   )
  )
  (if
   (i32.ge_s
    (global.get $global$5)
    (global.get $global$6)
   )
   (then
    (global.set $global$7
     (i32.const 1)
    )
    (return
     (call $0
      (i32.const 2)
     )
    )
   )
  )
  (if
   (select
    (global.get $global$7)
    (i32.const 0)
    (local.get $0)
   )
   (then
    (return
     (call $0
      (i32.const 3)
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $3 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $1
   (select
    (i32.const 64)
    (i32.const 2)
    (i32.eq
     (local.get $0)
     (i32.const 1)
    )
   )
  )
  (loop $label
   (if
    (i32.lt_s
     (local.get $2)
     (i32.const 16)
    )
    (then
     (local.set $1
      (if (result i32)
       (i32.or
        (i32.eq
         (local.tee $3
          (i32.load
           (i32.add
            (i32.mul
             (local.get $2)
             (i32.const 60)
            )
            (i32.const 1028)
           )
          )
         )
         (i32.const 3)
        )
        (i32.eq
         (local.get $3)
         (i32.const 2)
        )
       )
       (then
        (i32.add
         (local.get $1)
         (i32.add
          (select
           (select
            (i32.const 192)
            (i32.const 4)
            (local.tee $1
             (i32.eq
              (local.get $0)
              (i32.const 1)
             )
            )
           )
           (i32.const 3)
           (local.get $0)
          )
          (select
           (select
            (i32.const 64)
            (i32.const 2)
            (local.get $1)
           )
           (i32.const 2)
           (local.get $0)
          )
         )
        )
       )
       (else
        (if (result i32)
         (i32.eq
          (local.get $3)
          (i32.const 4)
         )
         (then
          (i32.add
           (local.get $1)
           (i32.add
            (call $5
             (local.get $2)
             (local.get $0)
            )
            (i32.load
             (i32.add
              (i32.shl
               (i32.add
                (local.get $0)
                (i32.mul
                 (local.get $2)
                 (i32.const 15)
                )
               )
               (i32.const 2)
              )
              (i32.const 1048)
             )
            )
           )
          )
         )
         (else
          (local.get $1)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (local.get $1)
 )
 (func $4 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (if
   (i32.le_s
    (local.get $0)
    (i32.const 0)
   )
   (then
    (return
     (call $0
      (i32.const 5)
     )
    )
   )
  )
  (local.set $1
   (i32.div_s
    (local.tee $0
     (i32.sub
      (local.get $0)
      (i32.const 1)
     )
    )
    (i32.const 96)
   )
  )
  (if
   (if (result i32)
    (i32.load
     (i32.add
      (local.tee $2
       (i32.shl
        (local.tee $0
         (i32.rem_s
          (local.get $0)
          (i32.const 96)
         )
        )
        (i32.const 5)
       )
      )
      (i32.const 1988)
     )
    )
    (then
     (i32.ne
      (local.get $1)
      (i32.load
       (i32.add
        (local.get $2)
        (i32.const 1984)
       )
      )
     )
    )
    (else
     (i32.const 1)
    )
   )
   (then
    (return
     (call $0
      (i32.const 5)
     )
    )
   )
  )
  (local.get $0)
 )
 (func $5 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (if (result i32)
   (call $21
    (local.get $0)
   )
   (then
    (select
     (local.tee $2
      (select
       (select
        (i32.const 64)
        (i32.const 2)
        (i32.eq
         (local.get $1)
         (i32.const 1)
        )
       )
       (i32.const 2)
       (local.get $1)
      )
     )
     (local.tee $0
      (select
       (local.tee $0
        (i32.sub
         (i32.load
          (i32.add
           (local.tee $0
            (i32.shl
             (i32.add
              (i32.mul
               (local.get $0)
               (i32.const 15)
              )
              (local.get $1)
             )
             (i32.const 2)
            )
           )
           (i32.const 1072)
          )
         )
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const 1048)
          )
         )
        )
       )
       (i32.const 0)
       (i32.ge_s
        (local.get $0)
        (i32.const 0)
       )
      )
     )
     (i32.gt_s
      (local.get $0)
      (local.get $2)
     )
    )
   )
   (else
    (i32.const 0)
   )
  )
 )
 (func $6 (result i32)
  (local $0 i32)
  (local $1 i32)
  (loop $label
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 16)
    )
    (then
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.load
        (i32.add
         (i32.mul
          (local.get $0)
          (i32.const 60)
         )
         (i32.const 1032)
        )
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (local.get $1)
 )
 (func $7 (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (result i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (block $block
   (br_if $block
    (i32.lt_s
     (call $2
      (i32.eq
       (local.get $4)
       (i32.const 1)
      )
     )
     (i32.const 0)
    )
   )
   (br_if $block
    (i32.lt_s
     (local.tee $6
      (call $1
       (local.get $0)
      )
     )
     (i32.const 0)
    )
   )
   (if
    (i32.or
     (i32.and
      (i32.ne
       (local.get $4)
       (i32.const 2)
      )
      (i32.ne
       (local.get $4)
       (i32.const 1)
      )
     )
     (i32.or
      (i32.or
       (i32.or
        (i32.or
         (i32.lt_s
          (i32.or
           (local.get $1)
           (local.get $2)
          )
          (i32.const 0)
         )
         (i32.le_s
          (local.get $3)
          (i32.const 0)
         )
        )
        (i32.gt_s
         (local.get $1)
         (i32.const 1000000)
        )
       )
       (i32.gt_s
        (local.get $2)
        (i32.const 1000000)
       )
      )
      (i32.gt_s
       (local.get $3)
       (i32.const 1000000)
      )
     )
    )
    (then
     (return
      (call $0
       (i32.const 6)
      )
     )
    )
   )
   (if
    (i32.or
     (i32.and
      (i32.eq
       (local.get $4)
       (i32.const 1)
      )
      (i32.ne
       (local.tee $7
        (i32.load
         (i32.add
          (i32.mul
           (local.get $6)
           (i32.const 60)
          )
          (i32.const 1028)
         )
        )
       )
       (i32.const 2)
      )
     )
     (i32.eq
      (local.get $7)
      (i32.const 1)
     )
    )
    (then
     (return
      (call $0
       (i32.const 3)
      )
     )
    )
   )
   (loop $label
    (if
     (i32.lt_s
      (local.get $5)
      (i32.const 3)
     )
     (then
      (local.set $9
       (select
        (select
         (local.get $2)
         (local.get $3)
         (local.tee $8
          (i32.eq
           (local.get $5)
           (i32.const 1)
          )
         )
        )
        (local.get $1)
        (local.get $5)
       )
      )
      (if
       (if (result i32)
        (i32.eq
         (local.get $4)
         (i32.const 1)
        )
        (then
         (i32.gt_s
          (i32.add
           (local.get $9)
           (i32.load
            (i32.add
             (i32.shl
              (i32.add
               (local.get $5)
               (i32.mul
                (local.get $6)
                (i32.const 15)
               )
              )
              (i32.const 2)
             )
             (i32.const 1060)
            )
           )
          )
          (select
           (select
            (i32.const 192)
            (i32.const 4)
            (local.get $8)
           )
           (i32.const 3)
           (local.get $5)
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return
         (call $0
          (i32.const 15)
         )
        )
       )
      )
      (if
       (if (result i32)
        (i32.eq
         (local.get $7)
         (i32.const 4)
        )
        (then
         (i32.lt_s
          (call $5
           (local.get $6)
           (local.get $5)
          )
          (local.get $9)
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (return
         (call $0
          (i32.const 16)
         )
        )
       )
      )
      (if
       (i32.gt_s
        (i32.add
         (local.get $9)
         (i32.load
          (i32.add
           (i32.shl
            (i32.add
             (local.get $5)
             (i32.mul
              (local.get $6)
              (i32.const 15)
             )
            )
            (i32.const 2)
           )
           (i32.const 1048)
          )
         )
        )
        (i32.add
         (select
          (select
           (i32.const 192)
           (i32.const 4)
           (local.tee $8
            (i32.eq
             (local.get $5)
             (i32.const 1)
            )
           )
          )
          (i32.const 3)
          (local.get $5)
         )
         (select
          (select
           (i32.const 64)
           (i32.const 2)
           (local.get $8)
          )
          (i32.const 2)
          (local.get $5)
         )
        )
       )
       (then
        (return
         (call $0
          (i32.const 17)
         )
        )
       )
      )
      (local.set $5
       (i32.add
        (local.get $5)
        (i32.const 1)
       )
      )
      (br $label)
     )
    )
   )
   (local.set $7
    (i32.add
     (local.tee $5
      (i32.mul
       (local.get $6)
       (i32.const 6)
      )
     )
     (select
      (i32.const 4)
      (i32.const 6)
      (i32.eq
       (local.get $4)
       (i32.const 1)
      )
     )
    )
   )
   (loop $label1
    (if
     (if (result i32)
      (i32.lt_s
       (local.get $5)
       (local.get $7)
      )
      (then
       (i32.load
        (i32.add
         (i32.shl
          (local.get $5)
          (i32.const 5)
         )
         (i32.const 1988)
        )
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (local.set $5
       (i32.add
        (local.get $5)
        (i32.const 1)
       )
      )
      (br $label1)
     )
    )
   )
   (if
    (i32.eq
     (local.get $5)
     (local.get $7)
    )
    (then
     (return
      (call $0
       (i32.const 18)
      )
     )
    )
   )
   (if
    (i32.gt_s
     (local.tee $8
      (i32.add
       (i32.load
        (i32.add
         (i32.shl
          (local.get $5)
          (i32.const 5)
         )
         (i32.const 1984)
        )
       )
       (i32.const 1)
      )
     )
     (i32.const 1000000)
    )
    (then
     (return
      (call $0
       (i32.const 9)
      )
     )
    )
   )
   (br_if $block
    (i32.lt_s
     (call $11
      (local.get $0)
      (local.get $4)
     )
     (i32.const 0)
    )
   )
   (i32.store
    (i32.add
     (local.tee $0
      (i32.shl
       (local.get $5)
       (i32.const 5)
      )
     )
     (i32.const 1984)
    )
    (local.get $8)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 1988)
    )
    (i32.const 1)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 1992)
    )
    (local.get $4)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 1996)
    )
    (i32.const 0)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 2000)
    )
    (local.get $1)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 2004)
    )
    (local.get $2)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 2008)
    )
    (local.get $3)
   )
   (i32.store
    (i32.add
     (local.get $0)
     (i32.const 2012)
    )
    (i32.const -1)
   )
   (local.set $0
    (i32.const 0)
   )
   (loop $label2
    (if
     (i32.lt_s
      (local.get $0)
      (i32.const 3)
     )
     (then
      (i32.store
       (local.tee $10
        (i32.add
         (local.tee $9
          (i32.shl
           (i32.add
            (i32.mul
             (local.get $6)
             (i32.const 15)
            )
            (local.get $0)
           )
           (i32.const 2)
          )
         )
         (i32.const 1048)
        )
       )
       (i32.add
        (local.tee $7
         (select
          (select
           (local.get $2)
           (local.get $3)
           (i32.eq
            (local.get $0)
            (i32.const 1)
           )
          )
          (local.get $1)
          (local.get $0)
         )
        )
        (i32.load
         (local.get $10)
        )
       )
      )
      (if
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
       (then
        (i32.store
         (local.tee $9
          (i32.add
           (local.get $9)
           (i32.const 1060)
          )
         )
         (i32.add
          (local.get $7)
          (i32.load
           (local.get $9)
          )
         )
        )
       )
      )
      (local.set $0
       (i32.add
        (local.get $0)
        (i32.const 1)
       )
      )
      (br $label2)
     )
    )
   )
   (global.set $global$16
    (i32.add
     (global.get $global$16)
     (i32.const 1)
    )
   )
   (global.set $global$15
    (select
     (local.tee $0
      (global.get $global$15)
     )
     (local.tee $1
      (global.get $global$16)
     )
     (i32.gt_s
      (local.get $0)
      (local.get $1)
     )
    )
   )
   (return
    (i32.add
     (i32.add
      (i32.mul
       (local.get $8)
       (i32.const 96)
      )
      (local.get $5)
     )
     (i32.const 1)
    )
   )
  )
  (i32.sub
   (i32.const 0)
   (global.get $global$9)
  )
 )
 (func $8 (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (if
   (i32.lt_s
    (local.tee $0
     (call $4
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.ne
    (local.get $2)
    (i32.load
     (i32.add
      (i32.shl
       (local.get $0)
       (i32.const 5)
      )
      (i32.const 1996)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 21)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.ne
     (local.get $1)
     (i32.const 4)
    )
    (i32.ne
     (local.get $1)
     (i32.const 3)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.eq
     (i32.load
      (i32.add
       (i32.shl
        (local.get $0)
        (i32.const 5)
       )
       (i32.const 1988)
      )
     )
     (i32.const 4)
    )
    (i32.ne
     (local.get $1)
     (i32.const 4)
    )
   )
   (then
    (return
     (call $0
      (i32.const 22)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.eq
     (i32.load
      (i32.add
       (i32.shl
        (local.get $0)
        (i32.const 5)
       )
       (i32.const 1988)
      )
     )
     (i32.const 1)
    )
    (i32.ne
     (local.get $1)
     (i32.const 4)
    )
   )
   (then
    (return
     (call $0
      (i32.const 19)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (i32.shl
     (local.get $0)
     (i32.const 5)
    )
    (i32.const 1988)
   )
   (local.get $1)
  )
  (i32.const 0)
 )
 (func $9 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (if
   (i32.lt_s
    (local.tee $2
     (call $4
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.or
    (i32.ne
     (i32.load
      (i32.add
       (i32.shl
        (local.get $2)
        (i32.const 5)
       )
       (i32.const 1988)
      )
     )
     (i32.const 1)
    )
    (i32.lt_s
     (local.get $1)
     (i32.const 0)
    )
   )
   (then
    (return
     (call $0
      (i32.const 19)
     )
    )
   )
  )
  (local.set $0
   (i32.const 0)
  )
  (loop $label
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 96)
    )
    (then
     (if
      (if (result i32)
       (if (result i32)
        (i32.ne
         (local.get $0)
         (local.get $2)
        )
        (then
         (if (result i32)
          (i32.eq
           (i32.load
            (i32.add
             (i32.shl
              (local.get $0)
              (i32.const 5)
             )
             (i32.const 1988)
            )
           )
           (i32.const 2)
          )
          (then
           (i32.const 1)
          )
          (else
           (i32.eq
            (i32.load
             (i32.add
              (i32.shl
               (local.get $0)
               (i32.const 5)
              )
              (i32.const 1988)
             )
            )
            (i32.const 4)
           )
          )
         )
        )
        (else
         (i32.const 0)
        )
       )
       (then
        (i32.eq
         (local.get $1)
         (i32.load
          (i32.add
           (i32.shl
            (local.get $0)
            (i32.const 5)
           )
           (i32.const 2012)
          )
         )
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (return
        (call $0
         (i32.const 20)
        )
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (i32.store
   (i32.add
    (local.tee $0
     (i32.shl
      (local.get $2)
      (i32.const 5)
     )
    )
    (i32.const 2012)
   )
   (local.get $1)
  )
  (i32.store
   (i32.add
    (local.get $0)
    (i32.const 1988)
   )
   (select
    (i32.const 4)
    (i32.const 2)
    (select
     (i32.const 1)
     (i32.ge_s
      (global.get $global$5)
      (global.get $global$6)
     )
     (global.get $global$8)
    )
   )
  )
  (i32.const 0)
 )
 (func $10 (param $0 i32)
  (if
   (i32.eqz
    (if (result i32)
     (i32.eq
      (i32.load
       (i32.add
        (i32.mul
         (local.get $0)
         (i32.const 60)
        )
        (i32.const 1028)
       )
      )
      (i32.const 4)
     )
     (then
      (call $21
       (local.get $0)
      )
     )
     (else
      (i32.const 1)
     )
    )
   )
   (then
    (i32.store
     (i32.add
      (i32.mul
       (local.get $0)
       (i32.const 60)
      )
      (i32.const 1028)
     )
     (i32.const 0)
    )
   )
  )
 )
 (func $11 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (if
   (i32.and
    (i32.ne
     (local.get $1)
     (i32.const 2)
    )
    (i32.ne
     (local.get $1)
     (i32.const 1)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (if
   (i32.lt_s
    (call $2
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.lt_s
    (local.tee $0
     (call $1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.or
    (i32.and
     (i32.eq
      (local.get $1)
      (i32.const 1)
     )
     (i32.ne
      (local.tee $2
       (i32.load
        (i32.add
         (i32.mul
          (local.get $0)
          (i32.const 60)
         )
         (i32.const 1028)
        )
       )
      )
      (i32.const 2)
     )
    )
    (i32.eq
     (local.get $2)
     (i32.const 1)
    )
   )
   (then
    (return
     (call $0
      (i32.const 3)
     )
    )
   )
  )
  (if
   (i32.ge_s
    (i32.load
     (i32.add
      (i32.shl
       (i32.add
        (local.tee $1
         (select
          (i32.const 4)
          (i32.const 5)
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
         )
        )
        (i32.mul
         (local.get $0)
         (i32.const 15)
        )
       )
       (i32.const 2)
      )
      (i32.const 1024)
     )
    )
    (i32.const 10000)
   )
   (then
    (return
     (call $0
      (i32.const 14)
     )
    )
   )
  )
  (i32.store
   (local.tee $0
    (i32.add
     (i32.shl
      (i32.add
       (i32.mul
        (local.get $0)
        (i32.const 15)
       )
       (local.get $1)
      )
      (i32.const 2)
     )
     (i32.const 1024)
    )
   )
   (i32.add
    (i32.load
     (local.get $0)
    )
    (i32.const 1)
   )
  )
  (i32.const 0)
 )
 (func $12 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (if
   (i32.lt_s
    (local.tee $2
     (call $1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.le_s
    (local.get $1)
    (i32.const 0)
   )
   (then
    (return
     (call $0
      (i32.const 13)
     )
    )
   )
  )
  (local.set $0
   (i32.div_s
    (local.tee $1
     (i32.sub
      (local.get $1)
      (i32.const 1)
     )
    )
    (i32.const 48)
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (i32.ne
      (i32.div_s
       (local.tee $1
        (i32.rem_s
         (local.get $1)
         (i32.const 48)
        )
       )
       (i32.const 3)
      )
      (local.get $2)
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.ne
       (local.get $0)
       (i32.load
        (i32.add
         (i32.shl
          (local.get $1)
          (i32.const 3)
         )
         (i32.const 5120)
        )
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.ne
      (i32.load
       (i32.add
        (i32.shl
         (local.get $1)
         (i32.const 3)
        )
        (i32.const 5124)
       )
      )
      (i32.const 1)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 13)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (i32.shl
     (local.get $1)
     (i32.const 3)
    )
    (i32.const 5124)
   )
   (i32.const 0)
  )
  (i32.store
   (local.tee $0
    (i32.add
     (i32.mul
      (local.get $2)
      (i32.const 60)
     )
     (i32.const 1036)
    )
   )
   (i32.sub
    (i32.load
     (local.get $0)
    )
    (i32.const 1)
   )
  )
  (i32.const 0)
 )
 (func $13 (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (if
   (i32.lt_s
    (local.tee $0
     (call $4
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.ne
    (i32.load
     (i32.add
      (i32.shl
       (local.get $0)
       (i32.const 5)
      )
      (i32.const 1988)
     )
    )
    (i32.const 3)
   )
   (then
    (return
     (call $0
      (i32.const 23)
     )
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (if (result i32)
      (i32.lt_s
       (i32.or
        (i32.or
         (local.get $1)
         (local.get $2)
        )
        (local.get $3)
       )
       (i32.const 0)
      )
      (then
       (i32.const 1)
      )
      (else
       (i32.gt_s
        (local.get $1)
        (i32.load
         (i32.add
          (i32.shl
           (local.get $0)
           (i32.const 5)
          )
          (i32.const 2000)
         )
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.gt_s
       (local.get $2)
       (i32.load
        (i32.add
         (i32.shl
          (local.get $0)
          (i32.const 5)
         )
         (i32.const 2004)
        )
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.gt_s
      (local.get $3)
      (i32.load
       (i32.add
        (i32.shl
         (local.get $0)
         (i32.const 5)
        )
        (i32.const 2008)
       )
      )
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 24)
     )
    )
   )
  )
  (local.set $7
   (i32.div_s
    (local.get $0)
    (i32.const 6)
   )
  )
  (loop $label
   (if
    (i32.lt_s
     (local.get $4)
     (i32.const 3)
    )
    (then
     (i32.store
      (local.tee $6
       (i32.add
        (i32.shl
         (i32.add
          (local.tee $5
           (i32.shl
            (local.get $0)
            (i32.const 3)
           )
          )
          (local.get $4)
         )
         (i32.const 2)
        )
        (i32.const 2000)
       )
      )
      (i32.sub
       (i32.load
        (local.get $6)
       )
       (local.tee $8
        (select
         (select
          (local.get $2)
          (local.get $3)
          (i32.eq
           (local.get $4)
           (i32.const 1)
          )
         )
         (local.get $1)
         (local.get $4)
        )
       )
      )
     )
     (i32.store
      (local.tee $6
       (i32.add
        (local.tee $9
         (i32.shl
          (i32.add
           (i32.mul
            (local.get $7)
            (i32.const 15)
           )
           (local.get $4)
          )
          (i32.const 2)
         )
        )
        (i32.const 1048)
       )
      )
      (i32.sub
       (i32.load
        (local.get $6)
       )
       (local.get $8)
      )
     )
     (if
      (i32.eq
       (i32.load
        (i32.add
         (i32.shl
          (local.get $5)
          (i32.const 2)
         )
         (i32.const 1992)
        )
       )
       (i32.const 1)
      )
      (then
       (i32.store
        (local.tee $5
         (i32.add
          (local.get $9)
          (i32.const 1060)
         )
        )
        (i32.sub
         (i32.load
          (local.get $5)
         )
         (local.get $8)
        )
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $4)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (if
   (i32.eqz
    (if (result i32)
     (if (result i32)
      (i32.load
       (i32.add
        (i32.shl
         (local.get $0)
         (i32.const 5)
        )
        (i32.const 2000)
       )
      )
      (then
       (i32.const 1)
      )
      (else
       (i32.load
        (i32.add
         (i32.shl
          (local.get $0)
          (i32.const 5)
         )
         (i32.const 2004)
        )
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.load
       (i32.add
        (i32.shl
         (local.get $0)
         (i32.const 5)
        )
        (i32.const 2008)
       )
      )
     )
    )
   )
   (then
    (i32.store
     (i32.add
      (local.tee $0
       (i32.shl
        (local.get $0)
        (i32.const 5)
       )
      )
      (i32.const 1988)
     )
     (i32.const 0)
    )
    (i32.store
     (i32.add
      (local.get $0)
      (i32.const 2012)
     )
     (i32.const -1)
    )
    (global.set $global$16
     (i32.sub
      (global.get $global$16)
      (i32.const 1)
     )
    )
    (call $10
     (local.get $7)
    )
   )
  )
  (i32.const 0)
 )
 (func $14 (param $0 i32) (param $1 i32) (result i32)
  (if
   (i32.or
    (i32.lt_s
     (local.get $0)
     (i32.const 0)
    )
    (i32.ge_s
     (local.get $0)
     (i32.const 32)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (i32.shl
     (local.get $0)
     (i32.const 2)
    )
    (i32.const 5504)
   )
   (local.get $1)
  )
  (i32.const 0)
 )
 (func $15 (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (result i32)
  (if
   (i32.or
    (i32.or
     (i32.or
      (i32.or
       (i32.or
        (i32.or
         (i32.or
          (i32.or
           (i32.lt_s
            (local.get $1)
            (i32.const 64)
           )
           (i32.lt_s
            (local.get $0)
            (i32.const 2)
           )
          )
          (i32.lt_s
           (local.get $2)
           (i32.const 2)
          )
         )
         (i32.gt_s
          (local.get $0)
          (i32.const 1000000)
         )
        )
        (i32.gt_s
         (local.get $1)
         (i32.const 1000000000)
        )
       )
       (i32.gt_s
        (local.get $2)
        (i32.const 1000000)
       )
      )
      (i32.lt_s
       (local.get $3)
       (i32.const 0)
      )
     )
     (i32.gt_s
      (local.get $3)
      (i32.const 1000000)
     )
    )
    (i32.le_s
     (local.get $4)
     (i32.const 0)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $0)
  )
  (global.set $global$1
   (local.get $1)
  )
  (global.set $global$2
   (local.get $2)
  )
  (global.set $global$3
   (local.get $3)
  )
  (global.set $global$6
   (local.get $4)
  )
  (global.set $global$5
   (i32.const 0)
  )
  (global.set $global$4
   (i32.const 0)
  )
  (global.set $global$7
   (i32.const 0)
  )
  (global.set $global$8
   (i32.const 0)
  )
  (global.set $global$9
   (i32.const 0)
  )
  (global.set $global$10
   (i32.const 0)
  )
  (global.set $global$11
   (i32.const 0)
  )
  (global.set $global$12
   (i32.const 0)
  )
  (global.set $global$13
   (i32.const 0)
  )
  (global.set $global$14
   (i32.const 0)
  )
  (global.set $global$15
   (i32.const 0)
  )
  (global.set $global$16
   (i32.const 0)
  )
  (local.set $0
   (i32.const 0)
  )
  (loop $label1
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 16)
    )
    (then
     (local.set $1
      (i32.const 1)
     )
     (loop $label
      (if
       (i32.lt_s
        (local.get $1)
        (i32.const 15)
       )
       (then
        (i32.store
         (i32.add
          (i32.shl
           (i32.add
            (i32.mul
             (local.get $0)
             (i32.const 15)
            )
            (local.get $1)
           )
           (i32.const 2)
          )
          (i32.const 1024)
         )
         (i32.const 0)
        )
        (local.set $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (br $label)
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (local.set $0
   (i32.const 0)
  )
  (loop $label3
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 98)
    )
    (then
     (local.set $1
      (i32.const 1)
     )
     (loop $label2
      (if
       (i32.lt_s
        (local.get $1)
        (i32.const 8)
       )
       (then
        (i32.store
         (i32.add
          (i32.shl
           (i32.add
            (i32.shl
             (local.get $0)
             (i32.const 3)
            )
            (local.get $1)
           )
           (i32.const 2)
          )
          (i32.const 1984)
         )
         (i32.const 0)
        )
        (local.set $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (br $label2)
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label3)
    )
   )
  )
  (local.set $0
   (i32.const 0)
  )
  (loop $label4
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 48)
    )
    (then
     (i32.store
      (i32.add
       (i32.shl
        (local.get $0)
        (i32.const 3)
       )
       (i32.const 5124)
      )
      (i32.const 0)
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label4)
    )
   )
  )
  (i32.const 0)
 )
 (func $16 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (if
   (i32.lt_s
    (local.tee $1
     (call $1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.and
    (i32.ne
     (local.tee $0
      (i32.load
       (i32.add
        (i32.mul
         (local.get $1)
         (i32.const 60)
        )
        (i32.const 1028)
       )
      )
     )
     (i32.const 3)
    )
    (i32.ne
     (local.get $0)
     (i32.const 2)
    )
   )
   (then
    (return
     (call $0
      (i32.const 10)
     )
    )
   )
  )
  (if
   (i32.load
    (i32.add
     (i32.mul
      (local.get $1)
      (i32.const 60)
     )
     (i32.const 1036)
    )
   )
   (then
    (return
     (call $0
      (i32.const 25)
     )
    )
   )
  )
  (local.set $0
   (i32.mul
    (local.get $1)
    (i32.const 6)
   )
  )
  (loop $label
   (if
    (i32.lt_s
     (local.get $0)
     (i32.add
      (i32.mul
       (local.get $1)
       (i32.const 6)
      )
      (i32.const 6)
     )
    )
    (then
     (if
      (i32.eq
       (i32.load
        (i32.add
         (i32.shl
          (local.get $0)
          (i32.const 5)
         )
         (i32.const 1988)
        )
       )
       (i32.const 1)
      )
      (then
       (return
        (call $0
         (i32.const 26)
        )
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (local.set $0
   (i32.const 0)
  )
  (loop $label1
   (if
    (i32.lt_s
     (local.get $0)
     (i32.const 3)
    )
    (then
     (local.set $2
      (i32.add
       (local.tee $3
        (select
         (select
          (i32.const 64)
          (i32.const 2)
          (local.tee $2
           (i32.eq
            (local.get $0)
            (i32.const 1)
           )
          )
         )
         (i32.const 2)
         (local.get $0)
        )
       )
       (select
        (select
         (i32.const 192)
         (i32.const 4)
         (local.get $2)
        )
        (i32.const 3)
        (local.get $0)
       )
      )
     )
     (local.set $4
      (i32.add
       (local.get $3)
       (i32.load
        (i32.add
         (local.tee $3
          (i32.shl
           (i32.add
            (i32.mul
             (local.get $1)
             (i32.const 15)
            )
            (local.get $0)
           )
           (i32.const 2)
          )
         )
         (i32.const 1048)
        )
       )
      )
     )
     (i32.store
      (i32.add
       (local.get $3)
       (i32.const 1072)
      )
      (select
       (local.get $2)
       (local.get $4)
       (i32.lt_s
        (local.get $2)
        (local.get $4)
       )
      )
     )
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (i32.store
   (i32.add
    (local.tee $0
     (i32.mul
      (local.get $1)
      (i32.const 60)
     )
    )
    (i32.const 1028)
   )
   (i32.const 4)
  )
  (i32.store
   (i32.add
    (local.get $0)
    (i32.const 1032)
   )
   (i32.const 0)
  )
  (call $10
   (local.get $1)
  )
  (i32.const 0)
 )
 (func $17
  (global.set $global$7
   (i32.const 1)
  )
  (global.set $global$8
   (i32.const 1)
  )
 )
 (func $18 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (if
   (i32.lt_s
    (call $2
     (i32.const 1)
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.lt_s
    (local.tee $2
     (call $1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (if (result i32)
    (i32.ne
     (i32.load
      (i32.add
       (i32.mul
        (local.get $2)
        (i32.const 60)
       )
       (i32.const 1028)
      )
     )
     (i32.const 2)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.le_s
      (i32.load
       (i32.add
        (i32.mul
         (local.get $2)
         (i32.const 60)
        )
        (i32.const 1032)
       )
      )
      (i32.const 0)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 12)
     )
    )
   )
  )
  (local.set $0
   (i32.mul
    (local.get $2)
    (i32.const 3)
   )
  )
  (loop $label
   (if
    (if (result i32)
     (i32.lt_s
      (local.get $0)
      (i32.add
       (i32.mul
        (local.get $2)
        (i32.const 3)
       )
       (i32.const 3)
      )
     )
     (then
      (i32.load
       (i32.add
        (i32.shl
         (local.get $0)
         (i32.const 3)
        )
        (i32.const 5124)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.add
     (i32.mul
      (local.get $2)
      (i32.const 3)
     )
     (i32.const 3)
    )
   )
   (then
    (return
     (call $0
      (i32.const 8)
     )
    )
   )
  )
  (if
   (i32.gt_s
    (local.tee $1
     (i32.add
      (i32.load
       (i32.add
        (i32.shl
         (local.get $0)
         (i32.const 3)
        )
        (i32.const 5120)
       )
      )
      (i32.const 1)
     )
    )
    (i32.const 1000000)
   )
   (then
    (return
     (call $0
      (i32.const 9)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (local.tee $3
     (i32.shl
      (local.get $0)
      (i32.const 3)
     )
    )
    (i32.const 5120)
   )
   (local.get $1)
  )
  (i32.store
   (i32.add
    (local.get $3)
    (i32.const 5124)
   )
   (i32.const 1)
  )
  (i32.store
   (local.tee $3
    (i32.add
     (local.tee $2
      (i32.mul
       (local.get $2)
       (i32.const 60)
      )
     )
     (i32.const 1032)
    )
   )
   (i32.sub
    (i32.load
     (local.get $3)
    )
    (i32.const 1)
   )
  )
  (i32.store
   (local.tee $2
    (i32.add
     (local.get $2)
     (i32.const 1036)
    )
   )
   (i32.add
    (i32.load
     (local.get $2)
    )
    (i32.const 1)
   )
  )
  (global.set $global$4
   (i32.add
    (global.get $global$4)
    (i32.const 1)
   )
  )
  (i32.add
   (i32.add
    (i32.mul
     (local.get $1)
     (i32.const 48)
    )
    (local.get $0)
   )
   (i32.const 1)
  )
 )
 (func $19 (result i32)
  (local $0 i32)
  (local $1 i32)
  (local $2 i32)
  (if
   (i32.lt_s
    (call $2
     (i32.const 1)
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.le_s
    (global.get $global$3)
    (i32.add
     (call $6)
     (global.get $global$4)
    )
   )
   (then
    (return
     (call $0
      (i32.const 7)
     )
    )
   )
  )
  (loop $label
   (if
    (if (result i32)
     (i32.lt_s
      (local.get $0)
      (i32.const 16)
     )
     (then
      (i32.load
       (i32.add
        (i32.mul
         (local.get $0)
         (i32.const 60)
        )
        (i32.const 1028)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (local.set $0
      (i32.add
       (local.get $0)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 16)
   )
   (then
    (return
     (call $0
      (i32.const 8)
     )
    )
   )
  )
  (if
   (i32.gt_s
    (local.tee $2
     (i32.add
      (i32.load
       (i32.add
        (i32.mul
         (local.get $0)
         (i32.const 60)
        )
        (i32.const 1024)
       )
      )
      (i32.const 1)
     )
    )
    (i32.const 1000000)
   )
   (then
    (return
     (call $0
      (i32.const 9)
     )
    )
   )
  )
  (local.set $1
   (i32.const 1)
  )
  (loop $label1
   (if
    (i32.lt_s
     (local.get $1)
     (i32.const 15)
    )
    (then
     (i32.store
      (i32.add
       (i32.shl
        (i32.add
         (i32.mul
          (local.get $0)
          (i32.const 15)
         )
         (local.get $1)
        )
        (i32.const 2)
       )
       (i32.const 1024)
      )
      (i32.const 0)
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (i32.store
   (i32.add
    (local.tee $1
     (i32.mul
      (local.get $0)
      (i32.const 60)
     )
    )
    (i32.const 1024)
   )
   (local.get $2)
  )
  (i32.store
   (i32.add
    (local.get $1)
    (i32.const 1028)
   )
   (i32.const 1)
  )
  (global.set $global$4
   (i32.add
    (global.get $global$4)
    (i32.const 1)
   )
  )
  (i32.add
   (i32.add
    (i32.shl
     (local.get $2)
     (i32.const 4)
    )
    (local.get $0)
   )
   (i32.const 1)
  )
 )
 (func $20 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (if
   (i32.lt_s
    (call $2
     (i32.const 1)
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.or
    (i32.lt_s
     (local.get $0)
     (i32.const 0)
    )
    (i32.gt_s
     (local.get $0)
     (i32.const 32)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (loop $label1
   (if
    (i32.gt_s
     (local.get $0)
     (local.get $1)
    )
    (then
     (if
      (i32.lt_s
       (local.tee $2
        (call $1
         (local.tee $3
          (i32.load
           (i32.add
            (i32.shl
             (local.get $1)
             (i32.const 2)
            )
            (i32.const 5504)
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (then
       (return
        (i32.sub
         (i32.const 0)
         (global.get $global$9)
        )
       )
      )
     )
     (if
      (i32.ne
       (i32.load
        (i32.add
         (i32.mul
          (local.get $2)
          (i32.const 60)
         )
         (i32.const 1028)
        )
       )
       (i32.const 1)
      )
      (then
       (return
        (call $0
         (i32.const 10)
        )
       )
      )
     )
     (local.set $2
      (i32.const 0)
     )
     (loop $label
      (if
       (i32.gt_s
        (local.get $1)
        (local.get $2)
       )
       (then
        (if
         (i32.eq
          (i32.load
           (i32.add
            (i32.shl
             (local.get $2)
             (i32.const 2)
            )
            (i32.const 5504)
           )
          )
          (local.get $3)
         )
         (then
          (return
           (call $0
            (i32.const 10)
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $2)
          (i32.const 1)
         )
        )
        (br $label)
       )
      )
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const 1)
      )
     )
     (br $label1)
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (i32.lt_s
      (global.get $global$0)
      (i32.add
       (call $3
        (i32.const 0)
       )
       (i32.mul
        (local.get $0)
        (i32.const 5)
       )
      )
     )
     (then
      (i32.const 1)
     )
     (else
      (i32.lt_s
       (global.get $global$1)
       (i32.add
        (call $3
         (i32.const 1)
        )
        (i32.shl
         (local.get $0)
         (i32.const 8)
        )
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.lt_s
      (global.get $global$2)
      (i32.add
       (call $3
        (i32.const 2)
       )
       (i32.mul
        (local.get $0)
        (i32.const 6)
       )
      )
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 11)
     )
    )
   )
  )
  (if
   (i32.lt_s
    (global.get $global$3)
    (i32.add
     (i32.add
      (call $6)
      (global.get $global$4)
     )
     (i32.mul
      (local.get $0)
      (i32.const 3)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 7)
     )
    )
   )
  )
  (local.set $1
   (i32.const 0)
  )
  (loop $label2
   (if
    (i32.gt_s
     (local.get $0)
     (local.get $1)
    )
    (then
     (i32.store
      (i32.add
       (local.tee $2
        (i32.mul
         (call $1
          (i32.load
           (i32.add
            (i32.shl
             (local.get $1)
             (i32.const 2)
            )
            (i32.const 5504)
           )
          )
         )
         (i32.const 60)
        )
       )
       (i32.const 1028)
      )
      (i32.const 2)
     )
     (i32.store
      (i32.add
       (local.get $2)
       (i32.const 1032)
      )
      (i32.const 3)
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const 1)
      )
     )
     (br $label2)
    )
   )
  )
  (i32.const 0)
 )
 (func $21 (param $0 i32) (result i32)
  (local $1 i32)
  (local.set $1
   (i32.mul
    (local.get $0)
    (i32.const 6)
   )
  )
  (loop $label
   (if
    (i32.lt_s
     (local.get $1)
     (i32.add
      (i32.mul
       (local.get $0)
       (i32.const 6)
      )
      (i32.const 6)
     )
    )
    (then
     (if
      (i32.load
       (i32.add
        (i32.shl
         (local.get $1)
         (i32.const 5)
        )
        (i32.const 1988)
       )
      )
      (then
       (return
        (i32.const 1)
       )
      )
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (i32.const 0)
 )
 (func $22 (param $0 i32) (result i32)
  (local $1 i32)
  (global.set $global$7
   (i32.const 1)
  )
  (global.set $global$13
   (i32.const 1)
  )
  (if
   (i32.lt_s
    (local.get $0)
    (i32.const 0)
   )
   (then
    (global.set $global$14
     (i32.const 1)
    )
    (return
     (call $0
      (i32.const 28)
     )
    )
   )
  )
  (local.set $1
   (i32.const 96)
  )
  (loop $label
   (if
    (if (result i32)
     (i32.lt_s
      (local.get $1)
      (i32.const 98)
     )
     (then
      (i32.load
       (i32.add
        (i32.shl
         (local.get $1)
         (i32.const 5)
        )
        (i32.const 1988)
       )
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
  )
  (if
   (i32.eq
    (local.get $1)
    (i32.const 98)
   )
   (then
    (global.set $global$14
     (i32.const 1)
    )
    (return
     (call $0
      (i32.const 28)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (local.tee $1
     (i32.shl
      (local.get $1)
      (i32.const 5)
     )
    )
    (i32.const 1988)
   )
   (i32.const 4)
  )
  (i32.store
   (i32.add
    (local.get $1)
    (i32.const 2012)
   )
   (local.get $0)
  )
  (i32.const 0)
 )
 (func $23
  (global.set $global$7
   (i32.const 1)
  )
 )
 (func $24 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (if
   (i32.and
    (i32.and
     (i32.le_s
      (local.get $0)
      (i32.const 3)
     )
     (i32.ge_s
      (local.get $0)
      (i32.const 0)
     )
    )
    (i32.or
     (i32.lt_s
      (local.get $1)
      (i32.const 0)
     )
     (i32.gt_s
      (local.get $1)
      (i32.const 2)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (if
   (i32.eqz
    (local.get $0)
   )
   (then
    (return
     (call $3
      (local.get $1)
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 1)
   )
   (then
    (local.set $3
     (select
      (select
       (global.get $global$11)
       (global.get $global$12)
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
      )
      (global.get $global$10)
      (local.get $1)
     )
    )
    (local.set $0
     (i32.const 0)
    )
    (loop $label
     (if
      (i32.lt_s
       (local.get $0)
       (i32.const 16)
      )
      (then
       (local.set $3
        (i32.add
         (local.get $3)
         (i32.load
          (i32.add
           (i32.shl
            (i32.add
             (local.get $1)
             (i32.mul
              (local.get $0)
              (i32.const 15)
             )
            )
            (i32.const 2)
           )
           (i32.const 1048)
          )
         )
        )
       )
       (local.set $0
        (i32.add
         (local.get $0)
         (i32.const 1)
        )
       )
       (br $label)
      )
     )
    )
    (return
     (local.get $3)
    )
   )
  )
  (if
   (i32.or
    (i32.eq
     (local.get $0)
     (i32.const 3)
    )
    (i32.eq
     (local.get $0)
     (i32.const 2)
    )
   )
   (then
    (loop $label1
     (if
      (i32.lt_s
       (local.get $3)
       (i32.const 16)
      )
      (then
       (if
        (i32.eq
         (i32.load
          (i32.add
           (i32.shl
            (local.tee $4
             (i32.mul
              (local.get $3)
              (i32.const 15)
             )
            )
            (i32.const 2)
           )
           (i32.const 1028)
          )
         )
         (i32.const 4)
        )
        (then
         (local.set $2
          (i32.add
           (if (result i32)
            (i32.eq
             (local.get $0)
             (i32.const 2)
            )
            (then
             (i32.load
              (i32.add
               (i32.shl
                (i32.add
                 (local.get $1)
                 (local.get $4)
                )
                (i32.const 2)
               )
               (i32.const 1048)
              )
             )
            )
            (else
             (call $5
              (local.get $3)
              (local.get $1)
             )
            )
           )
           (local.get $2)
          )
         )
        )
       )
       (local.set $3
        (i32.add
         (local.get $3)
         (i32.const 1)
        )
       )
       (br $label1)
      )
     )
    )
    (return
     (local.get $2)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 4)
   )
   (then
    (return
     (global.get $global$4)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 5)
   )
   (then
    (return
     (call $6)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 6)
   )
   (then
    (return
     (global.get $global$16)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 7)
   )
   (then
    (return
     (global.get $global$15)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 8)
   )
   (then
    (return
     (global.get $global$9)
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 9)
   )
   (then
    (return
     (i32.eqz
      (i32.eqz
       (global.get $global$14)
      )
     )
    )
   )
  )
  (if
   (i32.eq
    (local.get $0)
    (i32.const 10)
   )
   (then
    (return
     (i32.eqz
      (i32.eqz
       (global.get $global$13)
      )
     )
    )
   )
  )
  (i32.const 0)
 )
 (func $25 (result i32)
  (i32.const 1024)
 )
 (func $26 (param $0 i32) (result i32)
  (if
   (i32.or
    (i32.lt_s
     (local.get $0)
     (i32.const 0)
    )
    (i32.lt_s
     (local.get $0)
     (global.get $global$5)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (global.set $global$5
   (local.get $0)
  )
  (i32.const 0)
 )
 (func $27 (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (if
   (i32.lt_s
    (call $2
     (i32.const 1)
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.lt_s
    (local.tee $3
     (call $4
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (local.set $0
   (i32.lt_s
    (local.get $2)
    (i32.const 0)
   )
  )
  (if
   (if (result i32)
    (i32.or
     (i32.or
      (i32.or
       (if (result i32)
        (i32.ne
         (i32.load
          (i32.add
           (i32.shl
            (local.get $3)
            (i32.const 5)
           )
           (i32.const 1988)
          )
         )
         (i32.const 2)
        )
        (then
         (i32.const 1)
        )
        (else
         (i32.ne
          (local.get $1)
          (i32.load
           (i32.add
            (i32.shl
             (local.get $3)
             (i32.const 5)
            )
            (i32.const 1996)
           )
          )
         )
        )
       )
       (local.get $0)
      )
      (i32.gt_s
       (local.get $2)
       (i32.const 5)
      )
     )
     (i32.eq
      (local.get $1)
      (local.get $2)
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.ne
      (i32.load
       (i32.add
        (i32.mul
         (i32.div_s
          (local.get $3)
          (i32.const 6)
         )
         (i32.const 60)
        )
        (i32.const 1028)
       )
      )
      (i32.const 2)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 21)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (i32.shl
     (local.get $3)
     (i32.const 5)
    )
    (i32.const 1996)
   )
   (local.get $2)
  )
  (i32.const 0)
 )
 (func $28 (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (if
   (i32.lt_s
    (call $2
     (i32.const 0)
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.or
    (i32.or
     (i32.or
      (i32.lt_s
       (i32.or
        (i32.or
         (local.get $0)
         (local.get $1)
        )
        (local.get $2)
       )
       (i32.const 0)
      )
      (i32.gt_s
       (local.get $0)
       (i32.sub
        (i32.const 2)
        (global.get $global$10)
       )
      )
     )
     (i32.gt_s
      (local.get $1)
      (i32.sub
       (i32.const 64)
       (global.get $global$11)
      )
     )
    )
    (i32.gt_s
     (local.get $2)
     (i32.sub
      (i32.const 2)
      (global.get $global$12)
     )
    )
   )
   (then
    (return
     (call $0
      (i32.const 27)
     )
    )
   )
  )
  (global.set $global$10
   (i32.add
    (global.get $global$10)
    (local.get $0)
   )
  )
  (global.set $global$11
   (i32.add
    (global.get $global$11)
    (local.get $1)
   )
  )
  (global.set $global$12
   (i32.add
    (global.get $global$12)
    (local.get $2)
   )
  )
  (i32.const 0)
 )
 (func $29 (param $0 i32) (result i32)
  (if
   (i32.lt_s
    (local.tee $0
     (call $1
      (local.get $0)
     )
    )
    (i32.const 0)
   )
   (then
    (return
     (i32.sub
      (i32.const 0)
      (global.get $global$9)
     )
    )
   )
  )
  (if
   (i32.ne
    (i32.load
     (i32.add
      (i32.mul
       (local.get $0)
       (i32.const 60)
      )
      (i32.const 1028)
     )
    )
    (i32.const 1)
   )
   (then
    (return
     (call $0
      (i32.const 10)
     )
    )
   )
  )
  (i32.store
   (i32.add
    (i32.mul
     (local.get $0)
     (i32.const 60)
    )
    (i32.const 1028)
   )
   (i32.const 0)
  )
  (i32.const 0)
 )
 (func $30 (result i32)
  (i32.const 4608)
 )
 (func $31 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (if
   (i32.or
    (i32.or
     (i32.or
      (i32.lt_s
       (local.get $1)
       (i32.const 0)
      )
      (i32.gt_s
       (local.get $1)
       (i32.const 3)
      )
     )
     (i32.le_s
      (local.get $0)
      (i32.const 0)
     )
    )
    (i32.gt_s
     (local.get $0)
     (i32.const 1000000)
    )
   )
   (then
    (return
     (call $0
      (i32.const 6)
     )
    )
   )
  )
  (block $block
   (loop $label6
    (if
     (i32.gt_s
      (local.get $0)
      (local.get $4)
     )
     (then
      (drop
       (call $15
        (i32.const 42)
        (i32.const 2112)
        (i32.const 50)
        (i32.const 1024)
        (i32.const 100000)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (loop $label
       (if
        (i32.lt_s
         (local.get $2)
         (i32.const 8)
        )
        (then
         (drop
          (call $14
           (local.get $2)
           (call $19)
          )
         )
         (local.set $2
          (i32.add
           (local.get $2)
           (i32.const 1)
          )
         )
         (br $label)
        )
       )
      )
      (br_if $block
       (i32.lt_s
        (call $20
         (i32.const 8)
        )
        (i32.const 0)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (loop $label2
       (if
        (i32.lt_s
         (local.get $2)
         (i32.const 8)
        )
        (then
         (local.set $6
          (i32.load
           (i32.add
            (i32.shl
             (local.get $2)
             (i32.const 2)
            )
            (i32.const 5504)
           )
          )
         )
         (local.set $3
          (i32.const 0)
         )
         (loop $label1
          (if
           (i32.lt_s
            (local.get $3)
            (select
             (i32.const 3)
             (i32.const 1)
             (local.get $1)
            )
           )
           (then
            (br_if $block
             (if (result i32)
              (i32.lt_s
               (local.tee $7
                (call $18
                 (local.get $6)
                )
               )
               (i32.const 0)
              )
              (then
               (i32.const 1)
              )
              (else
               (i32.lt_s
                (call $12
                 (local.get $6)
                 (local.get $7)
                )
                (i32.const 0)
               )
              )
             )
            )
            (br_if $block
             (if (result i32)
              (i32.lt_s
               (local.tee $7
                (call $7
                 (local.get $6)
                 (i32.const 1)
                 (i32.const 64)
                 (select
                  (i32.const 2)
                  (i32.const 1)
                  (i32.eq
                   (local.get $3)
                   (i32.const 2)
                  )
                 )
                 (i32.const 1)
                )
               )
               (i32.const 0)
              )
              (then
               (i32.const 1)
              )
              (else
               (i32.lt_s
                (call $9
                 (local.get $7)
                 (i32.add
                  (i32.mul
                   (local.get $2)
                   (i32.const 10)
                  )
                  (local.get $3)
                 )
                )
                (i32.const 0)
               )
              )
             )
            )
            (local.set $3
             (i32.add
              (local.get $3)
              (i32.const 1)
             )
            )
            (br $label1)
           )
          )
         )
         (local.set $2
          (i32.add
           (local.get $2)
           (i32.const 1)
          )
         )
         (br $label2)
        )
       )
      )
      (if
       (i32.ge_s
        (local.get $1)
        (i32.const 2)
       )
       (then
        (global.set $global$7
         (i32.const 1)
        )
        (local.set $2
         (i32.const 0)
        )
        (loop $label3
         (if
          (i32.lt_s
           (local.get $2)
           (i32.const 8)
          )
          (then
           (br_if $block
            (if (result i32)
             (i32.lt_s
              (local.tee $3
               (call $7
                (i32.load
                 (i32.add
                  (i32.shl
                   (local.get $2)
                   (i32.const 2)
                  )
                  (i32.const 5504)
                 )
                )
                (i32.const 2)
                (i32.const 64)
                (i32.const 2)
                (i32.const 2)
               )
              )
              (i32.const 0)
             )
             (then
              (i32.const 1)
             )
             (else
              (i32.lt_s
               (call $9
                (local.get $3)
                (i32.add
                 (i32.mul
                  (local.get $2)
                  (i32.const 10)
                 )
                 (i32.const 3)
                )
               )
               (i32.const 0)
              )
             )
            )
           )
           (local.set $2
            (i32.add
             (local.get $2)
             (i32.const 1)
            )
           )
           (br $label3)
          )
         )
        )
       )
      )
      (local.set $5
       (i32.add
        (local.get $5)
        (global.get $global$16)
       )
      )
      (local.set $3
       (i32.const 0)
      )
      (loop $label5
       (if
        (i32.lt_s
         (local.get $3)
         (i32.const 8)
        )
        (then
         (local.set $2
          (local.tee $8
           (i32.mul
            (call $1
             (local.tee $9
              (i32.load
               (i32.add
                (i32.shl
                 (local.get $3)
                 (i32.const 2)
                )
                (i32.const 5504)
               )
              )
             )
            )
            (i32.const 6)
           )
          )
         )
         (loop $label4
          (if
           (i32.lt_s
            (local.get $2)
            (i32.add
             (local.get $8)
             (i32.const 6)
            )
           )
           (then
            (if
             (i32.load
              (i32.add
               (local.tee $6
                (i32.shl
                 (local.get $2)
                 (i32.const 5)
                )
               )
               (i32.const 1988)
              )
             )
             (then
              (block $block1
               (local.set $10
                (i32.add
                 (i32.add
                  (i32.mul
                   (i32.load
                    (i32.add
                     (local.get $6)
                     (i32.const 1984)
                    )
                   )
                   (i32.const 96)
                  )
                  (local.get $2)
                 )
                 (i32.const 1)
                )
               )
               (if
                (i32.and
                 (i32.eq
                  (local.get $2)
                  (local.get $8)
                 )
                 (i32.eq
                  (local.get $1)
                  (i32.const 3)
                 )
                )
                (then
                 (drop
                  (call $8
                   (local.get $10)
                   (i32.const 4)
                   (i32.const 0)
                  )
                 )
                 (br $block1)
                )
               )
               (local.set $6
                (i32.load
                 (i32.add
                  (local.tee $11
                   (i32.shl
                    (local.get $2)
                    (i32.const 5)
                   )
                  )
                  (i32.const 2000)
                 )
                )
               )
               (local.set $7
                (i32.load
                 (i32.add
                  (local.get $11)
                  (i32.const 2004)
                 )
                )
               )
               (local.set $11
                (i32.load
                 (i32.add
                  (local.get $11)
                  (i32.const 2008)
                 )
                )
               )
               (br_if $block
                (if (result i32)
                 (i32.lt_s
                  (call $8
                   (local.get $10)
                   (i32.const 3)
                   (i32.const 0)
                  )
                  (i32.const 0)
                 )
                 (then
                  (i32.const 1)
                 )
                 (else
                  (i32.lt_s
                   (call $13
                    (local.get $10)
                    (local.get $6)
                    (local.get $7)
                    (local.get $11)
                   )
                   (i32.const 0)
                  )
                 )
                )
               )
              )
             )
            )
            (local.set $2
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (br $label4)
           )
          )
         )
         (br_if $block
          (i32.lt_s
           (call $16
            (local.get $9)
           )
           (i32.const 0)
          )
         )
         (local.set $3
          (i32.add
           (local.get $3)
           (i32.const 1)
          )
         )
         (br $label5)
        )
       )
      )
      (call $17)
      (local.set $4
       (i32.add
        (local.get $4)
        (i32.const 1)
       )
      )
      (br $label6)
     )
    )
   )
   (return
    (local.get $5)
   )
  )
  (i32.sub
   (i32.const 0)
   (global.get $global$9)
  )
 )
)
