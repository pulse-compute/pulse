const cp = require('node:child_process');
const fs = require('node:fs');
const original = cp.spawnSync;
cp.spawnSync = function (...args) {
  const started = Date.now();
  const result = original.apply(this, args);
  const scenario = args[2]?.env?.SCENARIO;
  if (scenario) fs.appendFileSync('/tmp/ra02-sweep-probe-diagnostic.jsonl', JSON.stringify({scenario, runSmoke:args[2].env.RUN_SMOKE,elapsedMs:Date.now()-started,timeout:args[2].timeout,status:result.status,signal:result.signal,errorCode:result.error?.code,stderr:result.stderr})+'\n');
  return result;
};
