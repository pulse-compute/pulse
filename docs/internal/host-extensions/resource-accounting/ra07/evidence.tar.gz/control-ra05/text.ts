export default async function handler(ctx){const v=await ctx.fetch('https://origin.example/value').text();return ctx.text(v);}
