export default async function handler(ctx){const v=await ctx.fetch('https://origin.example/value',{timeoutMs:10}).text();return ctx.text(v);}
