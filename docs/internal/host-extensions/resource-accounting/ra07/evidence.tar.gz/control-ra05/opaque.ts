export default async function handler(ctx){return await ctx.fetch('https://origin.example/value');}
