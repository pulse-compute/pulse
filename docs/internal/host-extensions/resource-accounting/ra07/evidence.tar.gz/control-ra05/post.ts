export default async function handler(ctx){const v=await ctx.fetch('https://origin.example/value',{method:'POST',headers:{'x-proof':'yes'},body:'upload'}).text();return ctx.text(v);}
