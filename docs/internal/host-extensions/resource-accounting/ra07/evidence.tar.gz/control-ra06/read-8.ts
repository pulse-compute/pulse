import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await ctx.parallel({k0:cache.getText(ctx,'k0'),k1:cache.getText(ctx,'k1'),k2:cache.getText(ctx,'k2'),k3:cache.getText(ctx,'k3'),k4:cache.getText(ctx,'k4'),k5:cache.getText(ctx,'k5'),k6:cache.getText(ctx,'k6'),k7:cache.getText(ctx,'k7')}); return ctx.json(value);
}
