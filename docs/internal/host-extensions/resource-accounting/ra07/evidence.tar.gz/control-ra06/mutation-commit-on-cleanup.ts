import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await cache.putText(ctx,'k0','payload'); return ctx.json(value);
}
