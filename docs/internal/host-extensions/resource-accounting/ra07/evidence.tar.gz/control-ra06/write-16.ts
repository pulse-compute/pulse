import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await ctx.parallel({k0:cache.putText(ctx,'k0','payload'),k1:cache.putText(ctx,'k1','payload'),k2:cache.putText(ctx,'k2','payload'),k3:cache.putText(ctx,'k3','payload'),k4:cache.putText(ctx,'k4','payload'),k5:cache.putText(ctx,'k5','payload'),k6:cache.putText(ctx,'k6','payload'),k7:cache.putText(ctx,'k7','payload'),k8:cache.putText(ctx,'k8','payload'),k9:cache.putText(ctx,'k9','payload'),k10:cache.putText(ctx,'k10','payload'),k11:cache.putText(ctx,'k11','payload'),k12:cache.putText(ctx,'k12','payload'),k13:cache.putText(ctx,'k13','payload'),k14:cache.putText(ctx,'k14','payload'),k15:cache.putText(ctx,'k15','payload')}); return ctx.json(value);
}
