import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await ctx.parallel({k0:cache.getText(ctx,'k0'),k1:cache.getText(ctx,'k1'),k2:cache.getText(ctx,'k2'),k3:cache.getText(ctx,'k3'),k4:cache.getText(ctx,'k4'),k5:cache.getText(ctx,'k5'),k6:cache.getText(ctx,'k6'),k7:cache.getText(ctx,'k7'),k8:cache.getText(ctx,'k8'),k9:cache.getText(ctx,'k9'),k10:cache.getText(ctx,'k10'),k11:cache.getText(ctx,'k11'),k12:cache.getText(ctx,'k12'),k13:cache.getText(ctx,'k13'),k14:cache.getText(ctx,'k14'),k15:cache.getText(ctx,'k15')}); return ctx.json(value);
}
