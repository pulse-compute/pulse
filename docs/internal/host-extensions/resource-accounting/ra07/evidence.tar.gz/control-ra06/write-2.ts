import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await ctx.parallel({k0:cache.putText(ctx,'k0','payload'),k1:cache.putText(ctx,'k1','payload')}); return ctx.json(value);
}
