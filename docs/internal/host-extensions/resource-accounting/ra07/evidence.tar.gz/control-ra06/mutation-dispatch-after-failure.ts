import {cache} from '@hex-spike/cache';
export default async function handler(ctx) {
const value = await ctx.parallel({k0:cache.getText(ctx,'k0'),k1:cache.getText(ctx,'k1')}); return ctx.json(value);
}
