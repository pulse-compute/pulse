import {cache} from '@hex-spike/cache';
export default async function handler(ctx){
const value=await ctx.parallel({k0:cache.getOrSetText(ctx,'k0','https://origin.example/value'),k1:cache.getOrSetText(ctx,'k1','https://origin.example/value'),core:ctx.fetch('https://origin.example/value').text()});return ctx.json(value);
}
