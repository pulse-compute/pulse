import {cache} from '@hex-spike/cache';
export default async function handler(ctx){
const value=await cache.getOrSetText(ctx,'k0','https://origin.example/value');return ctx.json(value);
}
