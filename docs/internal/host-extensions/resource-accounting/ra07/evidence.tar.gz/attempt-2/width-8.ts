import {cache} from '@hex-spike/cache';
export default async function handler(ctx){
const value=await ctx.parallel({k0:cache.getOrSetText(ctx,'k0','https://origin.example/value'),k1:cache.getOrSetText(ctx,'k1','https://origin.example/value'),k2:cache.getOrSetText(ctx,'k2','https://origin.example/value'),k3:cache.getOrSetText(ctx,'k3','https://origin.example/value'),k4:cache.getOrSetText(ctx,'k4','https://origin.example/value'),k5:cache.getOrSetText(ctx,'k5','https://origin.example/value'),k6:cache.getOrSetText(ctx,'k6','https://origin.example/value'),k7:cache.getOrSetText(ctx,'k7','https://origin.example/value')});return ctx.json(value);
}
