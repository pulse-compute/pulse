export default async function handler(ctx){
return ctx.text('ok');
}
