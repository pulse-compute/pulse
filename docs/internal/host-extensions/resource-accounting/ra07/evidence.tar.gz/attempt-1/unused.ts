import {cache} from '@hex-spike/cache';
export default async function handler(ctx){
return ctx.text('ok');
}
